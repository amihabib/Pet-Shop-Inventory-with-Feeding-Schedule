﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkExample
{
    public class StartPage
    {
        public static string loggedInUser = ""; // to store the currently logged-in user
        public static void Main()
        {
            petshopdbcontext context = new petshopdbcontext();

            //Pet1 pet1 = new Pet1
            //{
            //    Type = "Dog",
            //    CageOrAquarium = "Cage"
            //};

            //FeedingSchedule1 feedingSchedule1 = new FeedingSchedule1
            //{
            //    CageOrAquarium = "Cage",
            //    Time = "10:00"
            //};  

            //Purchase purchase1 = new Purchase
            //{

            //    PetType = "Fish",
            //    Price = 20,
            //    SellerContact = "1234567890",
            //    PurchaseDate = "12/12/2020"
            //};

            //Sales sales1 = new Sales
            //{
            //    PetType = "Dog",
            //    SellPrice = 20,
            //    BuyerContact = "1234567890",
            //    SaleDate = "12/12/2020"
            //};



            //context.Pets1.Add(pet1);
            //context.FeedingSchedules1.Add(feedingSchedule1);
            //context.Purchase1.Add(purchase1);
            //context.Sales1.Add(sales1);
            //context.SaveChanges();


            while (true)
            {
                Console.WriteLine("Pet Shop Inventory System");
                Console.WriteLine("1. Login");
                Console.WriteLine("2. Exit");
                Console.Write("Enter your choice: ");

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        LoginHandler.Login(); // show error login doesn't exist here
                        break;
                    case 2:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkExample
{
    public class Purchase
    {
        public int PurchaseId { get; set; }
        public string? PetType { get; set; }
        public double Price { get; set; }
        public string? SellerContact { get; set; }

        public string? PurchaseDate { get; set; }

        //add a purchase
        public static void AddPurchase()
        {
            Console.WriteLine("Enter the pet type: ");
            string petType = Console.ReadLine();
            Console.WriteLine("Enter the price: ");
            double price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the seller contact: ");
            string sellerContact = Console.ReadLine();
            Console.WriteLine("Enter Purchase Date: ");
            string purchaseDate = Console.ReadLine();

            Purchase purchase = new Purchase
            {
                PetType = petType,
                Price = price,
                SellerContact = sellerContact,
                PurchaseDate = purchaseDate
            };

            using (var dbContext = new petshopdbcontext())
            {
                dbContext.Purchase1.Add(purchase);
                dbContext.SaveChanges();
            }

            Console.WriteLine("Purchase added successfully!");
        }
        public static void DeletePurchase()
        {
            Console.WriteLine("Enter the purchase id: ");
            int purchaseId = Convert.ToInt32(Console.ReadLine());

            using (var dbContext = new petshopdbcontext())
            {
                var purchase = dbContext.Purchase1.FirstOrDefault(p => p.PurchaseId == purchaseId);
                if (purchase != null)
                {
                    dbContext.Purchase1.Remove(purchase);
                    dbContext.SaveChanges();
                }
            }

            Console.WriteLine("Purchase deleted successfully!");
        }
        public static void UpdatePurchase()
        {
            Console.WriteLine("Enter the purchase id: ");
            int purchaseId = Convert.ToInt32(Console.ReadLine());

            using (var dbContext = new petshopdbcontext())
            {
                var purchase = dbContext.Purchase1.FirstOrDefault(p => p.PurchaseId == purchaseId);
                if (purchase != null)
                {
                    Console.WriteLine("Enter the pet type: ");
                    string petType = Console.ReadLine();
                    Console.WriteLine("Enter the price: ");
                    double price = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter the seller contact: ");
                    string sellerContact = Console.ReadLine();
                    Console.WriteLine("Enter the purchase date: ");
                    string purchaseDate = Console.ReadLine();

                    purchase.PetType = petType;
                    purchase.Price = price;
                    purchase.SellerContact = sellerContact;
                    purchase.PurchaseDate = purchaseDate;

                    dbContext.SaveChanges();
                }
            }

            Console.WriteLine("Purchase updated successfully!");
        }
        public static void ShowPurchase()
        {
            using (var dbContext = new petshopdbcontext())
            {
                var purchases = dbContext.Purchase1.ToList();
                foreach (var purchase in purchases)
                {
                    Console.WriteLine($"Purchase Id: {purchase.PurchaseId}");
                    Console.WriteLine($"Pet Type: {purchase.PetType}");
                    Console.WriteLine($"Price: {purchase.Price}$");
                    //Console.WriteLine($"Seller Contact: {purchase.SellerContact}");
                    Console.WriteLine($"Purchase Date: {purchase.PurchaseDate}");
                    Console.WriteLine();
                }
            }
        }

        public static double GetTotalPurchase()
        {
            double totalPurchase = 0;
            using (var dbContext = new petshopdbcontext())
            {
                var purchases = dbContext.Purchase1.ToList();
                foreach (var purchase in purchases)
                {
                    totalPurchase += purchase.Price;
                }
            }
            return totalPurchase;
        }




    }
}

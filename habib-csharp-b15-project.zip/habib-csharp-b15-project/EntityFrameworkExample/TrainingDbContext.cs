﻿//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Options;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace EntityFrameworkExample
//{
//    public class TrainingDbContext : DbContext
//    {

//        //public void EnableIdentityInsert(string tableName)
//        //{
//        //    string sql = $"SET IDENTITY_INSERT {tableName} ON;";
//        //    Database.ExecuteSqlRaw(sql);
//        //}
//        //public void DisableIdentityInsert(string tableName)
//        //{
//        //    string sql = $"SET IDENTITY_INSERT {tableName} OFF;";
//        //    Database.ExecuteSqlRaw(sql);
//        //}
//        private readonly string _connectionString;
//        public TrainingDbContext()
//        {
//            _connectionString = "Server=LAPTOP-MAVDPHME;Database=CSharpB15;User Id=csharpb15;Password=iamhabib; Trusted_Connection=true;TrustServerCertificate=True; Encrypt=False";

//        }
        
//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            if (optionsBuilder.IsConfigured == false)
//                optionsBuilder.UseSqlServer(_connectionString);

//            base.OnConfiguring(optionsBuilder);
//        }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<User>().HasData(GetAdmin());


//            modelBuilder.Entity<User>().HasKey(u => u.UserId);
//            modelBuilder.Entity<User>().Property(u => u.Username).IsRequired();
//            modelBuilder.Entity<User>().Property(u => u.Password).IsRequired();

//            base.OnModelCreating(modelBuilder);


//        }

//        private Pet GetPet()
//        {
//            return new Pet
//            {
//                Id = 1,
//                PetId = 1,
//                Type = "Dog",
//                CageOrAquarium = "Cage",
//                UserId = 1,
//                Cage = "Cage"
//            };
//        }


//        public DbSet<User> Users { get; set; }
//        //public DbSet<Pet1> Pets1 { get; set; }
//        //public DbSet<FeedingSchedule1> FeedingSchedules1 { get; set; }

//    }
//}

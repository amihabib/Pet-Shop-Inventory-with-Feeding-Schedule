﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkExample
{
    public class FeedingSchedule1
    {
        public int FeedingScheduleId { get; set; }
        public string? CageOrAquarium { get; set; }
        public string? Time { get; set; }

        public static void AddFeedingSchedule()
        {
            Console.WriteLine("Enter the cage or aquarium: ");
            string cageOrAquarium = Console.ReadLine();
            Console.WriteLine("Enter the time: ");
            string time = Console.ReadLine();

            FeedingSchedule1 feedingSchedule = new FeedingSchedule1
            {
                CageOrAquarium = cageOrAquarium,
                Time = time
            };

            using (var dbContext = new petshopdbcontext())
            {
                dbContext.FeedingSchedules1.Add(feedingSchedule);
                dbContext.SaveChanges();
            }

            Console.WriteLine("Feeding schedule added successfully!");
        }

        public static void DeleteFeedingSchedule()
        {
            Console.WriteLine("Enter the feeding schedule id: ");
            int feedingScheduleId = Convert.ToInt32(Console.ReadLine());

            using (var dbContext = new petshopdbcontext())
            {
                FeedingSchedule1 feedingSchedule = dbContext.FeedingSchedules1.Find(feedingScheduleId);
                dbContext.FeedingSchedules1.Remove(feedingSchedule);
                dbContext.SaveChanges();
            }

            Console.WriteLine("Feeding schedule deleted successfully!");
        }

        public static void UpdateFeedingSchedule()
        {
            Console.WriteLine("Enter the feeding schedule id: ");
            int feedingScheduleId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the cage or aquarium: ");
            string cageOrAquarium = Console.ReadLine();
            Console.WriteLine("Enter the time: ");
            string time = Console.ReadLine();

            using (var dbContext = new petshopdbcontext())
            {
                FeedingSchedule1 feedingSchedule = dbContext.FeedingSchedules1.Find(feedingScheduleId);
                feedingSchedule.CageOrAquarium = cageOrAquarium;
                feedingSchedule.Time = time;
                dbContext.SaveChanges();
            }

            Console.WriteLine("Feeding schedule updated successfully!");
        }

        public static void ShowFeedingSchedules()
        {
            using (var dbContext = new petshopdbcontext())
            {
                List<FeedingSchedule1> feedingSchedules = dbContext.FeedingSchedules1.ToList();
                foreach (FeedingSchedule1 feedingSchedule in feedingSchedules)
                {
                    Console.WriteLine("Feeding schedule id: " + feedingSchedule.FeedingScheduleId);
                    Console.WriteLine("Cage or aquarium: " + feedingSchedule.CageOrAquarium);
                    Console.WriteLine("Time: " + feedingSchedule.Time);
                    Console.WriteLine();
                }
            }
        }




    }
}

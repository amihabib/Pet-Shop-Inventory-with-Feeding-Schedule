﻿
using EntityFrameworkExample;
using System.Collections.Generic;
using System.Net.Security;
using System.Net.Sockets;
using System.Text;
using System.IO;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;

namespace EntityFrameworkExample
{
    public class Program
    {
        

        StartPage startPage = new StartPage();

        public static void MainMenu()
        {
            //using (var dbContext = new PetShopDbContext())
            //{
            //    dbContext.Database.Migrate();
            //}
            while (true)
            {
                Console.WriteLine("\nMain Menu");
                Console.WriteLine("1. Change Password");
                Console.WriteLine("2. ADD/UPDATE/DELETE/LIST OF PETS");
                Console.WriteLine("3. Feeding Schedule");
                Console.WriteLine("4. Purchase Record");
                Console.WriteLine("5. Sales Record");
                Console.WriteLine("6. Profit / Loss");
                Console.WriteLine("7. Log-Out");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    
                    case 1:
                        LoginHandler.ChangePassword();
                        break;
                    case 2:
                        Console.WriteLine("1. Add Pets");
                        Console.WriteLine("2. Delete Pets");
                        Console.WriteLine("3. Update Pets");
                        Console.WriteLine("4. Check List Pets");
                        Console.Write("Enter your choice: ");
                        int choice1 = Convert.ToInt32(Console.ReadLine());
                        switch (choice1)
                        {
                            case 1:
                                Pet1.AddPet();
                                break;
                            case 2:
                                Pet1.DeletePet();
                                break;
                            case 3:
                                Pet1.UpdatePet();
                                break;
                            case 4:
                                Pet1.ShowPets();
                                break;
                        }
                        break;
                    case 3:
                        Console.WriteLine("1. Add Schedule");
                        Console.WriteLine("2. Delete Schedule");
                        Console.WriteLine("3. Update Schedule");
                        Console.WriteLine("4. View Schedule List");
                        Console.Write("Enter your choice: ");
                        int choice2 = Convert.ToInt32(Console.ReadLine());
                        switch (choice2)
                        {
                            case 1:
                                FeedingSchedule1.AddFeedingSchedule();
                                break;
                            case 2:
                                FeedingSchedule1.DeleteFeedingSchedule();
                                break;
                            case 3:
                                FeedingSchedule1.UpdateFeedingSchedule();   
                                break;
                            case 4:
                                FeedingSchedule1.ShowFeedingSchedules();
                                break;
                        }
                        break;
                    case 4:
                        Console.WriteLine("1. Add Purchase");
                        Console.WriteLine("2. Delete Purchase");
                        Console.WriteLine("3. Update Purchase");
                        Console.WriteLine("4. View Purchase List");
                        Console.WriteLine("5. Total Purchase");
                        Console.Write("Enter your choice: ");
                        int choice3 = Convert.ToInt32(Console.ReadLine());
                        switch (choice3)
                        {
                            case 1:
                                Purchase.AddPurchase();
                                break;
                            case 2:
                                Purchase.DeletePurchase();
                                break;
                            case 3:
                                Purchase.UpdatePurchase();
                                break;
                            case 4:
                                Purchase.ShowPurchase();
                                break;
                            case 5:
                                double totalPurchase = Purchase.GetTotalPurchase();
                                Console.WriteLine($"Total Purchase : {totalPurchase}");
                                Purchase.GetTotalPurchase();
                                break;
                        }
                        break;
                    case 5:
                        Console.WriteLine("1. Add Sale");
                        Console.WriteLine("2. Delete Sale");
                        Console.WriteLine("3. Update Sale");
                        Console.WriteLine("4. View Sale List");
                        Console.WriteLine("5. Total Sales");
                        Console.Write("Enter your choice: ");
                        int choice4 = Convert.ToInt32(Console.ReadLine());
                        switch (choice4)
                        {
                            case 1:
                                Sales.AddSale();
                                break;
                            case 2:
                                Sales.DeleteSale();
                                break;
                            case 3:
                                Sales.UpdateSale();
                                break;
                            case 4:
                                Sales.DisplaySales();
                                break;
                            case 5:
                                double totalSales = Sales.TotalSales();
                                Console.WriteLine($"Total Sales : {totalSales}");
                                break;
                        }
                        break;
                    case 6: 
                        Console.WriteLine("1. Profit");
                        Console.WriteLine("2. Loss");
                        Console.Write("Enter your choice: ");
                        int choice5 = Convert.ToInt32(Console.ReadLine());
                        switch (choice5)
                        {
                            case 1:
                                Double totalSale = Sales.TotalSales();
                                Double totalPurchase = Purchase.GetTotalPurchase();
                                Double Profit = totalSale - totalPurchase;
                                if(Profit < 0)
                                {
                                    Profit = Profit * -1;
                                    Console.WriteLine($"There's no Profit. We're in {Profit}$ Loss.");
                                }
                                else
                                {
                                    Console.WriteLine($"Profit: {Profit} ");
                                }   
                                break;
                            case 2:
                                Double totalSale1 = Sales.TotalSales();
                                Double totalPurchase1= Purchase.GetTotalPurchase();
                                Double Loss = totalSale1 - totalPurchase1;
                                if(Loss >= 0)
                                {
                                    
                                    Console.WriteLine($"There's no Loss. We're in {Loss}$ Profit.");
                                }
                                else
                                {
                                    Loss = Loss * -1;
                                    Console.WriteLine($"Loss: {Loss} ");
                                }
                                break;
                        }
                        break;
                    case 7:
                        Console.WriteLine("Logging out...");
                        StartPage.loggedInUser = "";
                        StartPage.Main(); // Go back to the main menu
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
    }
}

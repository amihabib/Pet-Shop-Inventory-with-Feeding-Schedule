﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkExample
{
    public class Sales
    {
        public int SaleID { get; set; }
        public string? PetType { get; set; }
        public double SellPrice { get; set; }
        public string? BuyerContact { get; set; }

        public string? SaleDate { get; set; }

        //add a sale
        public static void AddSale()
        {
            Console.WriteLine("Enter the pet type: ");
            string petType = Console.ReadLine();
            Console.WriteLine("Enter the sell price: ");
            double sellPrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the buyer contact: ");
            string buyerContact = Console.ReadLine();
            Console.WriteLine("Enter Sales Date: ");
            string saleDate = Console.ReadLine();

            Sales sale = new Sales
            {
                PetType = petType,
                SellPrice = sellPrice,
                BuyerContact = buyerContact,
                SaleDate = saleDate
            };

            using (var dbContext = new petshopdbcontext())
            {
                dbContext.Sales1.Add(sale);
                dbContext.SaveChanges();
            }

            Console.WriteLine("Sale added successfully!");
        }
        public static void DeleteSale()
        {
            Console.WriteLine("Enter the sale id: ");
            int saleId = Convert.ToInt32(Console.ReadLine());

            using (var dbContext = new petshopdbcontext())
            {
                var sale = dbContext.Sales1.FirstOrDefault(s => s.SaleID == saleId);
                if (sale != null)
                {
                    dbContext.Sales1.Remove(sale);
                    dbContext.SaveChanges();
                }
            }

            Console.WriteLine("Sale deleted successfully!");
        }
        public static void UpdateSale()
        {
            Console.WriteLine("Enter the sale id: ");
            int saleId = Convert.ToInt32(Console.ReadLine());

            using (var dbContext = new petshopdbcontext())
            {
                var sale = dbContext.Sales1.FirstOrDefault(s => s.SaleID == saleId);
                if (sale != null)
                {
                    Console.WriteLine("Enter the pet type: ");
                    string petType = Console.ReadLine();
                    Console.WriteLine("Enter the sell price: ");
                    double sellPrice = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter the buyer contact: ");
                    string buyerContact = Console.ReadLine();
                    Console.WriteLine("Enter the sale date: ");
                    string saleDate = Console.ReadLine();

                    sale.PetType = petType;
                    sale.SellPrice = sellPrice;
                    sale.BuyerContact = buyerContact;
                    sale.SaleDate = saleDate;

                    dbContext.SaveChanges();
                }
            }

            Console.WriteLine("Sale updated successfully!");
        }
        public static void DisplaySales()
        {
            using (var dbContext = new petshopdbcontext())
            {
                var sales = dbContext.Sales1.ToList();
                foreach (var sale in sales)
                {
                    Console.WriteLine($"Sale ID: {sale.SaleID}");
                    Console.WriteLine($"Pet Type: {sale.PetType}");
                    Console.WriteLine($"Sell Price: {sale.SellPrice}$");
                    //Console.WriteLine($"Buyer Contact: {sale.BuyerContact}");
                    Console.WriteLine($"Sale Date: {sale.SaleDate}");
                    Console.WriteLine();
                }
            }
        }
        public static double TotalSales()
        {
            double totalSales = 0;
            using (var dbContext = new petshopdbcontext())
            {
                var sales = dbContext.Sales1.ToList();
                foreach (var sale in sales)
                {
                    totalSales += sale.SellPrice;
                }
            }
            return totalSales;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkExample
{
    public class Pet1
    {
        public int PetId { get; set; }
        public string Type { get; set; }
        public string CageOrAquarium { get; set; }

        public static void AddPet()
        {
            Console.WriteLine("Enter the pet type: ");
            string type = Console.ReadLine();
            Console.WriteLine("Enter the cage or aquarium: ");
            string cageOrAquarium = Console.ReadLine();

            Pet1 pet = new Pet1
            {
                Type = type,
                CageOrAquarium = cageOrAquarium
            };

            using (var dbContext = new petshopdbcontext())
            {
                dbContext.Pets1.Add(pet);
                dbContext.SaveChanges();
            }

            Console.WriteLine("Pet added successfully!");
        }

        public static void DeletePet()
        {
            Console.WriteLine("Enter the pet id: ");
            int petId = Convert.ToInt32(Console.ReadLine());

            using (var dbContext = new petshopdbcontext())
            {
                Pet1 pet = dbContext.Pets1.Find(petId);
                dbContext.Pets1.Remove(pet);
                dbContext.SaveChanges();
            }

            Console.WriteLine("Pet deleted successfully!");
        }

        public static void UpdatePet()
        {
            Console.WriteLine("Enter the pet id: ");
            int petId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the pet type: ");
            string type = Console.ReadLine();
            Console.WriteLine("Enter the cage or aquarium: ");
            string cageOrAquarium = Console.ReadLine();

            using (var dbContext = new petshopdbcontext())
            {
                Pet1 pet = dbContext.Pets1.Find(petId);
                pet.Type = type;
                pet.CageOrAquarium = cageOrAquarium;
                dbContext.SaveChanges();
            }

            Console.WriteLine("Pet updated successfully!");
        }

        //checking list of pets in the inventory
        public static void ShowPets()
        {
            using (var dbContext = new petshopdbcontext())
            {
                List<Pet1> pets = dbContext.Pets1.ToList();
                foreach (Pet1 pet in pets)
                {
                    Console.WriteLine("Pet Id: {0}, Type: {1}, Cage or Aquarium: {2}", pet.PetId, pet.Type, pet.CageOrAquarium);
                }
            }
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkExample
{
    public class LoginHandler
    {

        public static void Login()
        {
            using (var dbContext = new petshopdbcontext())
            {
                Console.Write("Enter username: ");
                string username = Console.ReadLine();

                Console.Write("Enter password: ");
                string password = Console.ReadLine();

                // Fetch user from the database
                var user = dbContext.Users.SingleOrDefault(u => u.Username==username && u.Password == password);

                if (user != null)
                {
                    Console.WriteLine($"Welcome, {user.Username}!");
                    StartPage.loggedInUser = username;
                    //    Console.WriteLine($"Welcome, {StartPage.loggedInUser}!");
                    Program.MainMenu();
                }
                else
                {
                    Console.WriteLine("Invalid username or password. Please try again.");
                }
            }

        }

        public static void ChangePassword()
        {
            using (var dbContext = new petshopdbcontext())
            {
                Console.Write("Enter your current password: ");
                string currentPassword = Console.ReadLine();

                // Fetch user from the database based on the logged-in user
                var user = dbContext.Users.SingleOrDefault(u => u.Username == StartPage.loggedInUser && u.Password == currentPassword);

                if (user != null)
                {
                    Console.Write("Enter your new password: ");
                    string newPassword = Console.ReadLine();

                    // Update the user's password in the database
                    user.Password = newPassword;
                    dbContext.SaveChanges();

                    Console.WriteLine("Password changed successfully!");
                }
                else
                {
                    Console.WriteLine("Invalid current password. Password change failed.");
                }
            }
        }
    }
}

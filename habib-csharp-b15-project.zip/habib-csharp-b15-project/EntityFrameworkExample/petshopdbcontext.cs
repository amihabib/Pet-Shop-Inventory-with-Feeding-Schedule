﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkExample
{
    public class petshopdbcontext : DbContext
    {

        
        private readonly string _connectionString;
        public petshopdbcontext()
        {
            _connectionString = "Server=LAPTOP-MAVDPHME;Database=petshopdb;User Id=petuser;Password=123456; Trusted_Connection=true;TrustServerCertificate=True; Encrypt=False";

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured == false)
                optionsBuilder.UseSqlServer(_connectionString);

            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(GetAdmin());

            modelBuilder.Entity<Pet1>().HasKey(p => p.PetId);

            modelBuilder.Entity<FeedingSchedule1>().HasKey(f => f.FeedingScheduleId);

            modelBuilder.Entity<Purchase>().HasKey(p => p.PurchaseId);
            
            modelBuilder.Entity<Sales>().HasKey(u => u.SaleID);
       

            base.OnModelCreating(modelBuilder);


        }

        public DbSet<User> Users { get; set; }
        public DbSet<Pet1> Pets1 { get; set; }
        public DbSet<FeedingSchedule1> FeedingSchedules1 { get; set; }

        public DbSet<Purchase> Purchase1 { get; set; }

        public DbSet<Sales> Sales1 { get; set; }

        private User GetAdmin()
        {
            return new User
            {
                UserId = 1,
                Username = "admin",
                Password = "123456"
            };
        }




    }
}
